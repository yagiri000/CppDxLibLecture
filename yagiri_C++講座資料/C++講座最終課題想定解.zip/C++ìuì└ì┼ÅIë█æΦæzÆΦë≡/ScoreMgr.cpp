#include "GameMgr.h"
#include "myglobal.h"
#include <DxLib.h>
#include <iostream>
#include "Input.h"

ScoreMgr::ScoreMgr() :
nowscore(0)
{
}

void ScoreMgr::addscore(int n){
	nowscore += n;
}

int ScoreMgr::getscore(){
	return nowscore;
}

void ScoreMgr::addhitnum(){
	hitnum++;
}

int ScoreMgr::gethitnum(){
	return hitnum;
}

void ScoreMgr::update(){

}

void ScoreMgr::draw(){
	DrawFormatStringToHandle(20, 20, 0xFFFFFF, FontHandle, "SCORE %d", nowscore);
	DrawFormatStringToHandle(20, 40, 0xFFFFFF, FontHandle, "��e�� %d", hitnum);
}