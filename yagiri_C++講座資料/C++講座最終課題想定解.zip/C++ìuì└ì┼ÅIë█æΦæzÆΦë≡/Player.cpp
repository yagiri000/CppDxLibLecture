#include "GameMgr.h"
#include "myglobal.h"
#include <DxLib.h>
#include <iostream>
#include "Input.h"


Player::Player() :
x(ScreenWidth / 2),
y(ScreenHeight * 7 / 8),
fireCool(0),
r(16),
fireRate(5),
moveSpeed(5.0)
{
}


void Player::update(){
	move();
	shot();
	checkHit();
}

//�ړ�
void Player::move(){
	double vx = 0.0;
	double vy = 0.0;

	if (Input::keynow(KEY_INPUT_UP)){
		vy = -1.0;
	}
	if (Input::keynow(KEY_INPUT_DOWN)){
		vy = 1.0;
	}
	if (Input::keynow(KEY_INPUT_RIGHT)){
		vx = 1.0;
	}
	if (Input::keynow(KEY_INPUT_LEFT)){
		vx = -1.0;
	}

	x += moveSpeed * vx;
	y += moveSpeed * vy;
}

//�e����
void Player::shot(){
	fireCool++;
	if (Input::keynow(KEY_INPUT_Z)){
		if (fireCool >= fireRate){
			GameMgr::get().p_bullet_.add(x, y - 20, 0, -15.0);
			fireCool = 0;
		}
	}
}

void Player::checkHit(){
	//�G�e���玩�@�ւ̓����蔻��
	for (auto &i = GameMgr::get().e_bullet_.v.begin(); i < GameMgr::get().e_bullet_.v.end(); i++){
		auto &obj = **i;
		if (IsColCircles(x, y, r, obj.x, obj.y, obj.r) && obj.IsDead == false){
			for (int j = 0; j < 64; j++){
				double range = 128;
				GameMgr::get().effect_.add(std::make_shared<WhiteCircle>(x + RandRange(-range, range), y + RandRange(-range, range)));
			}
			GameMgr::get().score_.addhitnum();
			obj.IsDead = true;
		}
	}

	//�G���g���玩�@�ւ̓����蔻��
	for (auto &i = GameMgr::get().enemy_.v.begin(); i < GameMgr::get().enemy_.v.end(); i++){
		auto &obj = **i;
		if (IsColCircles(x, y, r, obj.x, obj.y, obj.r) && obj.IsDead == false){
			for (int j = 0; j < 64; j++){
				double range = 128;
				GameMgr::get().effect_.add(std::make_shared<WhiteCircle>(x + RandRange(-range, range), y + RandRange(-range, range)));
			}
			GameMgr::get().score_.addhitnum();
			obj.IsDead = true;
		}
	}
}

//�`��
void Player::draw(){
	DrawCircle(x, y, r, 0xFF8800, 1);
}