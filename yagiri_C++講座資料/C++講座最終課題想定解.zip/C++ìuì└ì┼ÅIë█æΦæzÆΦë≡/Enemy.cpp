#include "GameMgr.h"
#include "myglobal.h"
#include <DxLib.h>
#include <iostream>
#include <algorithm>
#include "Input.h"


//�G�̊��N���X
IEnemy::IEnemy(double x_, double y_) :
x(x_), y(y_),
r(32),
vx(0), vy(0),
hp(5),
eframe(0),
IsDead(false),
score(100)
{
}

void IEnemy::update(){
	move();
	shot();
	framecount();
	hit();
	isdead();
}

void IEnemy::move(){
	x += vx;
	y += vy;
}

void IEnemy::shot(){

}

void IEnemy::framecount(){
	eframe++;
}

void IEnemy::hit(){
	auto &vec = GameMgr::get().p_bullet_.v;
	for (auto &i = vec.begin(); i < vec.end(); i++){
		auto &obj = **i;
		if (IsColCircles(x, y, r, obj.x, obj.y, obj.r) && obj.IsDead == false){
			hp -= obj.attack;
			GameMgr::get().effect_.add(std::make_shared<WhiteCircle>(obj.x, obj.y));
			obj.IsDead = true;
		}
	}
}

void IEnemy::isdead(){
	//��ʊO�ɍs���������m�F
	int marge = 100;
	if (x < -marge || x > ScreenWidth + marge || y < -marge || y > ScreenHeight + marge){
		IsDead = true;
	}
	//HP���[�������m�F
	if (hp < 0.1){
		GameMgr::get().score_.addscore(score);
		for (int j = 0; j < 25; j++){
			double range = 64;
			GameMgr::get().effect_.add(std::make_shared<WhiteCircle>(x + RandRange(-range, range), y + RandRange(-range, range)));
		}
		IsDead = true;
	}
}




//���@�Ɍ������Ă���G
EnemyA::EnemyA(double x_, double y_) : IEnemy(x_, y_), 
moveSpeed(1.5)
{
	double angle = getangle(x, y, GameMgr::get().player_.getx(), GameMgr::get().player_.gety());
	vx = moveSpeed * cos(angle);
	vy = moveSpeed * sin(angle);
}

void EnemyA::draw(){
	DrawCircle(x, y, r, 0xFF0000, 1);
}




//�������Ɍ����Ă���G
EnemyB::EnemyB(double x_, double y_) : IEnemy(x_, y_),
shotRate(60),
bulletSpeed(1.0)
{
	vx = 0;
	vy = 0;
}

void EnemyB::shot(){
	if (eframe % shotRate == 0){
		double fx, fy, angle;
		angle = getangle(x, y, GameMgr::get().player_.getx(), GameMgr::get().player_.gety());
		fx = bulletSpeed * cos(angle);
		fy = bulletSpeed * sin(angle);
		GameMgr::get().e_bullet_.add(x, y, fx, fy);
	}
}

void EnemyB::draw(){
	DrawCircle(x, y, r, 0x000088, 1);
}




//�����ʒu�ŉ��Ȃ���4�����Ɍ����Ă���G
EnemyC::EnemyC(double x_, double y_) : IEnemy(x_, y_),
shotRate(120),
bulletSpeed(8.0),
moveOmega(0.02)
{
	vx = 0;
	vy = 0;
}

void EnemyC::shot(){
	if (eframe % shotRate == 0){
		for (int i = 0; i < 4; i++){
			double angle = i * PI * 0.5;
			double fx = bulletSpeed * cos(angle);
			double fy = bulletSpeed * sin(angle);
			GameMgr::get().e_bullet_.add(x, y, fx, fy);
		}
	}
}

void EnemyC::move(){
	x += cos(eframe * moveOmega);
	y += sin(eframe * moveOmega);
}

void EnemyC::draw(){
	DrawCircle(x, y, r, 0xFF00FF, 1);
}



//�G���Ǘ�����N���X
EnemyMgr::EnemyMgr(){
}

void EnemyMgr::update(){
	for (const auto &i : v){
		i->update();
	}
	//IsDead��true�Ȃ珜��
	auto rmv = std::remove_if(v.begin(), v.end(),
		[](std::shared_ptr<IEnemy> p)->bool{
		return p->IsDead;
	}
	);
	v.erase(rmv, v.end());
}

void EnemyMgr::draw(){
	for (const auto &i : v){
		i->draw();
	}
}

void EnemyMgr::add(std::shared_ptr<IEnemy> sptr){
	v.emplace_back(sptr);
}