#include "GameMgr.h"
#include "myglobal.h"
#include <DxLib.h>
#include <iostream>
#include <algorithm>
#include "Input.h"


//�e�G�t�F�N�g�̊��N���X
IEffect::IEffect(double x_, double y_) :
x(x_),
y(y_),
IsDead(false),
e_frame(0)
{
}

void IEffect::update(){
	move();
	framecount();
}


void IEffect::framecount(){
	e_frame++;
	if (e_frame >= del_frame){
		IsDead = true;
	}
}



//�����~����u�`�悷��G�t�F�N�g
WhiteCircle::WhiteCircle(double x_, double y_) : IEffect(x_, y_){
	del_frame = 5;
}

void WhiteCircle::move(){

}

void WhiteCircle::draw(){
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 80);
	DrawCircle(x, y, 64, 0xFFFFFF, 1);
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 255);
}



//�G�t�F�N�g�̊Ǘ��N���X
EffectMgr::EffectMgr(){
}

void EffectMgr::add(std::shared_ptr<IEffect> sptr){
	v.emplace_back(sptr);
}

void EffectMgr::update(){
	for (const auto &i : v){
		i->update();
	}
	//IsDead��true�Ȃ珜��
	auto rmv = std::remove_if(v.begin(), v.end(),
		[](std::shared_ptr<IEffect> p)->bool{
		return p->IsDead;
	}
	);
	v.erase(rmv, v.end());
}

void EffectMgr::draw(){
	for (const auto &i : v){
		i->draw();
	}
}

