#include "GameMgr.h"

GameMgr& mgr = GameMgr::get();