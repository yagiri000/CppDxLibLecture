#pragma once

class ScoreMgr{
private:
	int nowscore;
	int hitnum;

public:
	ScoreMgr();

	void addscore(int n);
	int getscore();
	void addhitnum();
	int gethitnum();

	void update();
	void draw();
};