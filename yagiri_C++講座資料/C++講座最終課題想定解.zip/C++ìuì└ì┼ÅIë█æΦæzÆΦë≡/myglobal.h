#pragma once
#include <iostream>

const int ScreenWidth = 600;
const int ScreenHeight = 600;

const double PI = 4 * atan(1);
const double DegPerRad = PI / 180.0f;
const double RadPerDeg = 180.0f / PI;
const double SQRT2 = sqrt(2.0);

extern int FontHandle;

bool IsColCircles(double ax, double ay, double ar, double bx, double by, double br);

double getangle(double sx, double sy, double ex, double ey);

double RandRange(double a, double b);