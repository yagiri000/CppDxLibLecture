#pragma once

#include <vector>
#include <memory>



class EnemyBullet
{
private:
	double vx, vy;
	int remainTime;

public:
	double x, y;
	const double r = 8;
	bool IsDead;

	EnemyBullet(double x, double y, double vx, double vy);

	void update();

	void move();

	void countFrame();

	void draw();
};


class EnemyBulletMgr{
public:
	std::vector<std::shared_ptr<EnemyBullet>> v;

	EnemyBulletMgr();

	//�e����
	void add(double x, double y, double vx, double vy);

	void update();

	void draw();
};
