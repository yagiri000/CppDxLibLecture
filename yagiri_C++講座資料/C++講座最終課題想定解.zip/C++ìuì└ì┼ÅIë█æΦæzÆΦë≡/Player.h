#pragma once



class Player
{
private:
	double x, y;
	int fireCool;

public:
	const int r;
	const int fireRate;
	const double moveSpeed;

	Player();
	void update();
	void draw();

	void move();
	void shot();
	void checkHit();

	double getx(){ return x; }
	double gety(){ return y; }
};
