#include "GameMgr.h"
#include "myglobal.h"
#include <DxLib.h>
#include <iostream>
#include <algorithm>



PlayerBullet::PlayerBullet(double x, double y, double vx, double vy) :
x(x),
y(y),
vx(vx),
vy(vy),
r(4),
attack(1.0),
remainTime(60),
IsDead(false)
{
}

void PlayerBullet::update(){
	countFrame();
	move();
}

void PlayerBullet::move(){
	x += vx;
	y += vy;
}

void PlayerBullet::countFrame(){
	remainTime--;
	if (remainTime < 1){
		IsDead = true;
	}
}

void PlayerBullet::draw(){
	DrawCircle(x, y, r, 0x888888, 1);
}


PlayerBulletMgr::PlayerBulletMgr(){
}

//�e����
void PlayerBulletMgr::add(double x, double y, double vx, double vy){
	v.emplace_back(std::make_shared<PlayerBullet>(x, y, vx, vy));
}

void PlayerBulletMgr::update(){
	for (const auto &i : v){
		i->update();
	}
	//IsDead��true�Ȃ珜��
	auto rmv = std::remove_if(v.begin(), v.end(),
		[](std::shared_ptr<PlayerBullet> p)->bool{
		return p->IsDead;
	}
	);
	v.erase(rmv, v.end());
}

void PlayerBulletMgr::draw(){
	for (const auto &i : v){
		i->draw();
	}
}
