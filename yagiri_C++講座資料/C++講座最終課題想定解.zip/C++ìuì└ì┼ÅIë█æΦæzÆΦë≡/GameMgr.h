#pragma once

#include <iostream>
#include "DxLib.h"
#include "myglobal.h"
#include "Player.h"
#include "PlayerBullet.h"
#include "Enemy.h"
#include "EnemyBullet.h"
#include "Effect.h"
#include "ScoreMgr.h"

class GameMgr{
public:
	GameMgr(const GameMgr& r) = delete;//�R�s�[�֎~
	GameMgr& operator=(const GameMgr& r) = delete;//����֎~

	static GameMgr& get(){
		static GameMgr inst;
		return inst;
	}

	Player player_;
	PlayerBulletMgr p_bullet_;
	EnemyMgr enemy_;
	EnemyBulletMgr e_bullet_;
	EffectMgr effect_;
	ScoreMgr score_;

	void update(){
		player_.update();
		enemy_.update();
		p_bullet_.update();
		e_bullet_.update();
		effect_.update();
		score_.update();
	}

	void draw(){
		player_.draw();
		enemy_.draw();
		p_bullet_.draw();
		e_bullet_.draw();
		effect_.draw();
		score_.draw();
	}

	void load(){
		FontHandle = CreateFontToHandle("Segoe UI", 20, 5, DX_FONTTYPE_ANTIALIASING_4X4);
	}


private:
	GameMgr()
	{
	};

};

extern GameMgr& mgr;