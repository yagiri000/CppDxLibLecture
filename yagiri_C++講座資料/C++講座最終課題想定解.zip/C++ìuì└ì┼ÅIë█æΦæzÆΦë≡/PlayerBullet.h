#pragma once

#include <memory>
#include <vector>


class PlayerBullet
{
private:
	double vx, vy;
	int remainTime;

public:
	double x, y;
	const int r;
	const double attack;
	bool IsDead;

	PlayerBullet(double x, double y, double vx, double vy);

	void update();

	void move();

	void countFrame();

	void draw();
};


class PlayerBulletMgr{
public:
	std::vector<std::shared_ptr<PlayerBullet>> v;

	PlayerBulletMgr();

	//�e����
	void add(double x, double y, double vx, double vy);

	void update();

	void draw();
};
