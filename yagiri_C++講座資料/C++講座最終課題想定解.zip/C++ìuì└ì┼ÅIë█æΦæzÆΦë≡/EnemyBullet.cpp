#include "GameMgr.h"
#include "myglobal.h"
#include <DxLib.h>
#include <iostream>
#include <algorithm>
#include "Input.h"


EnemyBullet::EnemyBullet(double x, double y, double vx, double vy) :
x(x),
y(y),
vx(vx),
vy(vy),
remainTime(999),
IsDead(false)
{
}

void EnemyBullet::update(){
	countFrame();
	move();
}

void EnemyBullet::move(){
	x += vx;
	y += vy;
}

void EnemyBullet::countFrame(){
	remainTime--;
	if (remainTime < 1){
		IsDead = true;
	}
}

void EnemyBullet::draw(){
	DrawCircle(x, y, r, 0xFFFFFF, 1);
}


EnemyBulletMgr::EnemyBulletMgr(){
}

//�e����
void EnemyBulletMgr::add(double x, double y, double vx, double vy){
	v.emplace_back(std::make_shared<EnemyBullet>(x, y, vx, vy));
}

void EnemyBulletMgr::update(){
	for (const auto &i : v){
		i->update();
	}
	//IsDead��true�Ȃ珜��
	auto rmv = std::remove_if(v.begin(), v.end(),
		[](std::shared_ptr<EnemyBullet> p)->bool{
		return p->IsDead;
	}
	);
	v.erase(rmv, v.end());
}

void EnemyBulletMgr::draw(){
	for (const auto &i : v){
		i->draw();
	}
}
